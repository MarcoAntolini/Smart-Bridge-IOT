#ifndef __STATE__
#define __STATE__

enum class State
{
    NORMAL_SITUATION,
    ALARM_SITUATION,
    PRE_ALARM_SITUATION
};

#endif